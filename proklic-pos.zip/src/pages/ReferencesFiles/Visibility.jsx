import React from 'react'
import Header from '../../components/Header'

const Visibility = () => {
  return (
    <div>
        <Header title="Visibility" subtitle="Visibility" />
    </div>
  )
}

export default Visibility