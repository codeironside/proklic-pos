import React from 'react'
import Header from '../../components/Header'

const View = () => {
  return (
    <div>
        <Header title="Views" subtitle="Views" />
    </div>
  )
}

export default View