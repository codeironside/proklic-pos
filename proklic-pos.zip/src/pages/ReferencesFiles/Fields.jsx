import React from 'react'
import Header from '../../components/Header'

const Fields = () => {
  return (
    <div>
        <Header title="Fields" subtitle="Fields" ></Header>
    </div>
  )
}

export default Fields